#! /usr/bin/env python3

import subprocess
import os
import sys
import time
from unittest import result
import argparse

"""
So each .case file will have lines, each line needs to be passed to the
tokeniser in sequence, we compare the output tokens to the expected output
in .golden file.
"""

"""
Ensure we are in the root of the project
"""
toplvl = subprocess.run(["git", "rev-parse", "--show-toplevel"], capture_output=True, text=True)
if toplvl.returncode != 0:
	print("Error: Not a git repository", file=sys.stderr)
	sys.exit(1)
toplevel = toplvl.stdout.strip()
os.chdir(toplevel)

tester = None
args = None
cases_dir = os.path.join(toplevel, "auto_test", "fsm_tokeniser", "cases")
golden_dir = os.path.join(toplevel, "auto_test", "fsm_tokeniser", "golden")

def compile_tester():
	"""
	Compile the tester program.
	"""
	# First check if the test file exists
	test_file = os.path.join(toplevel, "auto_test", "fsm_tokeniser", "test.c")
	if not os.path.isfile(test_file):
		print(f"Error: Test file not found: {test_file}", file=sys.stderr)
		sys.exit(1)
	
	compile_argv = [
		"make",
		f"MAIN={test_file}",
		"CFLAGS=-g3 -O0" if args.no_asan else "CFLAGS=-g3 -O0 -fsanitize=address,undefined -fno-omit-frame-pointer"
	]
	if args.verbose:
		print("Compiling tester...")
		print(" ".join(compile_argv))

	ret = subprocess.run(
		compile_argv,
		stdout=subprocess.PIPE,
		stderr=subprocess.PIPE,
		text=True
	)
	if ret.returncode != 0:
		print("Error: Failed to compile tester", file=sys.stderr)
		print("STDOUT:", file=sys.stderr)
		print(ret.stdout, file=sys.stderr)
		print("STDERR:", file=sys.stderr)
		print(ret.stderr, file=sys.stderr)
		sys.exit(1)
	global tester
	tester = os.path.join(toplevel, "minishell")  # The Makefile creates "minishell" binary
	if not os.path.isfile(tester):
		print("Error: Tester binary not found after compilation", file=sys.stderr)
		sys.exit(1)

def run_case(casefile):
	"""
	Run a single test case from the given casefile.
	"""
	with open(casefile, "r") as f:
		lines = f.readlines()
	# Join all lines into a single argument instead of separate arguments
	input_text = ''.join(lines).strip()
	if not input_text:  # Handle empty input case
		acmdv = [tester, ""]
	else:
		acmdv = [tester, input_text]
	ret = subprocess.run(
		acmdv,
		stdout=subprocess.PIPE,
		stderr=subprocess.PIPE,
		text=True
	)
	if ret.returncode != 0:
		print(f"Error: Tester failed for case {casefile}", file=sys.stderr)
		print(ret.stdout, file=sys.stderr)
		print(ret.stderr, file=sys.stderr)
		return None
	return ret

def compare_result(result, goldenfile):
	"""
	Compare the result of a test case with the expected output in the golden file.
	"""
	with open(goldenfile, "r") as f:
		expected = f.read()
	if result.stdout.strip() == expected.strip():
		return True
	else:
		print("Expected:")
		print(expected)
		print("Got:")
		print(result.stdout)
		return False

def check_asan(result):
	"""
	Check the stderr output for ASAN errors.
	"""
	if "ERROR: AddressSanitizer" in result.stderr or "ERROR: UndefinedBehaviorSanitizer" in result.stderr:
		print("ASAN/UBSAN error detected:")
		print(result.stderr)
		return False
	return True

def create_golden(casefile):
	"""
	Create a golden file from the result of a test case.
	"""
	result = run_case(casefile)
	if result is None:
		return False
	goldenfile = casefile.replace("cases", "golden").replace(".case", ".golden")
	with open(goldenfile, "w") as f:
		f.write(result.stdout)
	print(f"Created golden file: {goldenfile}")
	return True


if __name__ == "__main__":
	argparser = argparse.ArgumentParser(description="FSM Tokeniser Auto Tester")
	argparser.add_argument("--update-golden", action="store_true", help="Update golden files instead of testing")
	argparser.add_argument("--case", type=str, help="Run a specific test case file")
	argparser.add_argument("--verbose", action="store_true", help="Enable verbose output")
	argparser.add_argument("--no-asan", action="store_true", help="Disable ASAN/UBSAN checks")
	argparser.add_argument("--time", action="store_true", help="Enable timing of test cases")
	args = argparser.parse_args()
	compile_tester()
	if args.case:
		casefiles = [args.case]
	else:
		casefiles = [os.path.join(cases_dir, f) for f in os.listdir(cases_dir) if f.endswith(".case")]
	if not casefiles:
		print("No test cases found.", file=sys.stderr)
		sys.exit(1)
	failed = 0
	for casefile in casefiles:
		if args.verbose:
			print(f"Running case: {casefile}")
		if args.update_golden:
			time_start = time.time() if args.time else None
			print(f"Updating golden for case: {casefile}")
			if not create_golden(casefile):
				failed += 1
			if args.time:
				time_end = time.time()
				print(f"Time taken: {time_end - time_start:.4f} seconds")
			continue
		time_start = time.time() if args.time else None
		result = run_case(casefile)
		if args.time:
			time_end = time.time()
			print(f"Time taken for {casefile}: {time_end - time_start:.4f} seconds")
		if result is None:
			print(f"Test case failed to run: {casefile}", file=sys.stderr)
			failed += 1
			continue
		goldenfile = casefile.replace("cases", "golden").replace(".case", ".golden")
		if not os.path.isfile(goldenfile):
			print(f"Golden file not found for case {casefile}, skipping comparison.", file=sys.stderr)
			failed += 1
			continue
		if not compare_result(result, goldenfile):
			print(f"Test case failed: {casefile}", file=sys.stderr)
			failed += 1
			continue
		if not args.no_asan and not check_asan(result):
			print(f"ASAN/UBSAN check failed for case {casefile}", file=sys.stderr)
			failed += 1
			continue
		if args.verbose:
			print(f"Test case passed: {casefile}")
	if failed > 0:
		print(f"{failed} test case(s) failed.", file=sys.stderr)
		sys.exit(1)
	print("All test cases passed.")